/*Elabore um programa que leia dois valores e apresente os resultados das quatro opera��es aritm�ticas
b�sicas realizadas entre eles.
*/
#include<stdio.h>
	int main (void){
	float n1, n2, D, M, S, N;
	printf ("\n Digite 2 numeros:");
	scanf ("%f", &n1);
	scanf ("%f", &n2);
	
	D= n1/n2;
	M= n1*n2;
	S= n1+n2;
	N= n1-n2;
	
	printf ("\n Valores finais s�o respectivamente:%f",D);
	printf ("\n Valores finais s�o respectivamente:%f",M);
	printf ("\n Valores finais s�o respectivamente:%f",S);
	printf ("\n Valores finais s�o respectivamente:%f",N);
	
	return 0;
}
