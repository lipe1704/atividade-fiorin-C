/*Desenvolva um algoritmo para calcular a quantidade de litros de combust�vel que um autom�vel que faz m�dia de 12Km/L precisa para uma viagem. O usu�rio deve informar a dist�ncia do trajeto e o algoritmo deve calcular a quantidade de litros atrav�s da seguinte f�rmula: LitrosUsados = dist�ncia / 12  
*/
#include <stdio.h>
int main (void){
	float D, QL;
	
	printf ("\n informe a distancia em km de seu trajeto");
	scanf ("%f", &D);
	QL= D/12;
	printf ("\n a quantidade de litros gasta e: %f", QL);
	
	return 0;
}
