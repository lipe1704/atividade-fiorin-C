/* Desenvolva um algoritmo para um programa que leia tr�s valores inteiros e apresente como resultado  o valor do quadrado da soma dos tr�s valores lidos.  
*/
#include<stdio.h>
int main (void){
	float s, n, n1, n2, t;
	printf ("\n Digite 3 numeros:");
	scanf ("%f", &n);
	scanf ("%f", &n1);
	scanf ("%f", &n2);
	
	s= n+n1+n2;
	t = s*s;
	
	printf ("\n O resultado da soma �:%f",t);
	
	return 0;
}

