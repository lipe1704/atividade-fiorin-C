/*Desenvolva um algoritmo para um programa que leia tr�s valores inteiros e apresente como resultado o
valor da soma dos quadrados dos tr�s valores lidos.
*/
#include<stdio.h>
int main (void){
	float s, n, n1, n2;
	printf ("\n Digite 3 numeros:");
	scanf ("%f", &n);
	scanf ("%f", &n1);
	scanf ("%f", &n2);
	
	n=n*n;
	n1=n1*n1;
	n2=n2*n2;
	s= n+n1+n2;
	
	printf ("\n O resultado da soma �:%f",s);
	
	return 0;
}

