/*Fa�a um algoritmo para calcular o volume de uma lata cil�ndrica atrav�s da seguinte f�rmula:
Vol = 3,14. r�. h. O algoritmo deve receber o valor do raio (r) e da altura (h) e, ap�s calcular o volume,
mostrar o resultado ao usu�rio. Procure empregar o conceito de constantes e vari�veis neste problema.
*/

#include <stdio.h>
int main (void){
    float r, h, vol;
    
    printf ("\n Informe a altura do recipiente:");
    scanf ("%f" , &h);
    printf ("\n Informe o raio do recipiente:");
    scanf ("%f" , &r);
    
    vol= 3.14 * r * r * h;
    
    printf ("\n O volume da lata �: %f", vol);
    
    return 0;
}
