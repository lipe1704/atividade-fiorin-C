/*	Fa�a um algoritmo que solicite a idade de 4 pessoas. O algoritmo deve calcular a m�dia aritm�tica das idades e apresentar o resultado na tela.*/
#include <stdio.h>
int main (void){
	float S, M, N1, N2, N3, N4;
	
	printf ("\n informe 4 idades");
	scanf ("%f", &N1);
	scanf ("%f", &N2);
	scanf ("%f", &N3);
	scanf ("%f", &N4);
	S = N1 + N2 + N3 + N4;
	
	M= S/4;
	
	printf ("\n a media das 4 idades inseridas e: %f", M);
	
	return 0;
}
