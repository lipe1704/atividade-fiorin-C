/*	Escreva um algoritmo que pe�a para o usu�rio informar a sua idade e, em seguida, calcule e apresente o dobro e o triplo da idade informada.  */
#include <stdio.h>
	int main (void){
	float I, D, T ;
	
	printf ("\n informe a sua idade");
	scanf ("%f", &I);

	I= I;
	D= I*2;
	T= I*3;
	printf ("\n a idade: %f", I);
	printf ("\n o dobro da idade: %f", D);
	printf ("\n o triplo da idade e: %f", T);
	return 0;
}
