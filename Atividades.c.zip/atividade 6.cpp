/*Escreva um algoritmo que receba um valor em Real e a cota��o do D�lar, calcule a convers�o do valor e, como sa�da, apresente o valor a ser convertido (R$), a cota��o do D�lar e o valor da convers�o ($). Exemplo:  
*/
#include <stdio.h>
int main (void){
	float T, D, R;
	printf ("\n informe a cotacao do dolar");
	scanf ("%f", &D);
	printf ("\n informe a quantidade de reais a ser convertida");
	scanf ("%f", &R);
	printf ("\n o dolar e: %f", D);
	printf ("\n o real e: %f", R);
	
	T= R/D;
	
	printf ("\n resultado em reais e: %f", T);
	
	return 0;
}
 

