/*Escreva um algoritmo para ler dos valores para as vari�veis A e B. O algoritmo deve efetuar a troca dos
valores, de forma que a vari�vel A passe a possuir o valor de B e a vari�vel B passe a possuir o valor de
A. O algoritmo deve apresentar os valores ao usu�rio, antes e depois da troca.
*/
#include <stdio.h>
int main (){
     int  a, b, c;
     printf ("Informe um valor para a: \n");
     scanf ("%d", &a);
     
     c = a;
     a = b;
     b = c;
     
     printf ("\n Valores trocados: \n A: %d \n B: %d a, b");
     
     return 0;
}
